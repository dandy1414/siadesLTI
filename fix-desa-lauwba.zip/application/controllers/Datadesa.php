<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Datadesa
 *
 * @author Lenovo
 */
class Datadesa extends CI_Controller {
    function form() {
        $this->load->view('datadesa');
    }
    
    function index() {
        $this->load->view('datadesa');
    }
 
    
}
