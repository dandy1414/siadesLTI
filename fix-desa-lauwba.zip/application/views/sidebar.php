  <div id="left-menu">
              <div class="sub-left-menu scroll">
                <ul class="nav nav-list">
                   <!--<img src="<?php echo base_url();?>asset/img/pdam.jpg" width="220" height="150">-->
                    <!-- <li><div class="left-bg"></div></li> -->
                    <li class="time">
                      <h1 class="animated fadeInLeft">21:00</h1>
                      <p class="animated fadeInRight">Sat,October 1st 2029</p>
                    </li>
                      
                    <li class="active ripple">
                      <a href="<?php Echo site_url('Berita/index')?>">
                        <span class="fa-home fa"></span>Berita</a>
                    </li>
<!--                    <li class="active ripple">
                      <a href="<?php Echo site_url('Kategori/index')?>">
                        <span class="fa-home fa"></span>Kategori</a>
                    </li>-->
                     <li class="active ripple">
                      <a href="<?php Echo site_url('Pengumuman/index')?>">
                        <span class="fa-home fa"></span>Pengumuman</a>
                    </li>
                    
                     <li class="active ripple">
                      <a href="<?php Echo site_url('Galeri/index')?>">
                        <span class="fa-home fa"></span>Galeri</a>
                    </li>
                     <li class="ripple"><a class="tree-toggle nav-header">
                      <span class="fa-home fa"></span>Data Desa<span class="fa-angle-right fa right-arrow text-right"></span> </a>
                      <ul class="nav nav-list tree">
                       <li class="ripple"><a href="<?php echo site_url('Balita')?>"><span class="fa fa-table"></span>Balita</a></li>
                       <li class="ripple"><a href="<?php echo site_url('Pendidikan')?>"><span class="fa fa-table"></span>Pendidikan</a></li>
                        <li class="ripple"><a href="<?php echo site_url('Keluarga')?>"><span class="fa fa-table"></span>Keluarga</a></li>
                        <li class="ripple"><a href="<?php echo site_url('Lansia')?>"><span class="fa fa-table"></span>Lansia</a></li>
                        <li class="ripple"><a href="<?php echo site_url('Penduduk')?>"><span class="fa fa-table"></span>Penduduk</a></li>
                      </ul>
                    </li>
                    <li class="active ripple">
                      <a href="<?php Echo site_url('Programdesa/index')?>">
                        <span class="fa-home fa"></span>Program Desa</a>
                    </li>
                    <li class="active ripple">
                      <a href="<?php Echo site_url('Layanan/index')?>">
                        <span class="fa-home fa"></span>Layanan</a>
                    </li>
                    <li class="active ripple">
                      <a href="<?php Echo site_url('Potensidesa/index')?>">
                        <span class="fa-home fa"></span>Potensi Desa</a>
                    </li>
                     <li class="active ripple">
                      <a href="<?php Echo site_url('Lembaga/index')?>">
                        <span class="fa-home fa"></span>Lembaga</a>
                    </li>
                    
                    
                      </ul>
                    </li>
                    <li><a href="credits.html">#</a></li>
                  </ul>
                </div>
            </div>
           
           