<!DOCTYPE html>
<html lang="en">
<head>
  
  <meta charset="utf-8">
  <meta name="description" content="Miminium Admin Template v.1">
  <meta name="author" content="Isna Nur Azis">
  <meta name="keyword" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Desa Lauwba</title>

  <!-- start: Css -->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>asset/css/bootstrap.min.css">
  
  <link href="<?php echo base_url('asset/date_picker_bootstrap/bootstrap-datetimepicker.min.css') ?>" rel="stylesheet" media="screen">
        <link href="<?php echo base_url('asset/date_picker_bootstrap/bootstrap-datetimepicker.css') ?>" rel="stylesheet" media="screen">
        <link href="<?php echo base_url('asset/css/bootstrap.min.css') ?>" rel="stylesheet" media="screen">
   <!-- plugins -->
  <!-- end: Css -->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>asset/css/plugins/font-awesome.min.css"/>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>asset/css/plugins/datatables.bootstrap.min.css"/>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>asset/css/plugins/animate.min.css"/>
   <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>asset/css/plugins/bootstrap-material-datetimepicker.css"/>
  <link href="<?php echo base_url();?>asset/css/style.css" rel="stylesheet">
  <!-- end: Css -->

  <!--<link rel="shortcut icon" href="<?php echo base_url();?>asset/img/pam.png">-->
 
  </head>

<body id="mimin" class="dashboard">
      <!-- start: Header -->
        <nav class="navbar navbar-default header navbar-fixed-top">
          <div class="col-md-12 nav-wrapper">
            <div class="navbar-header" style="width:100%;">
              <div class="opener-left-menu is-open">
                <span class="top"></span>
                <span class="middle"></span>
                <span class="bottom"></span>
              </div>
<!--              
-->                 <a href="index.html" class="navbar-brand"> 
                 <b>Desa Lauwba</b>
                </a> <!--
                  <img src="<?php echo base_url();?>asset/img/pdam.jpg" width="75" height="55"> -->
              <ul class="nav navbar-nav navbar-right user-nav">
                <li class="user-name"><span></span></li>
                  <li class="dropdown avatar-dropdown">
                   <img src="<?php echo base_url();?>asset/img/avatar.jpg" class="img-circle avatar" alt="user name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true"/>
                   <ul class="dropdown-menu user-dropdown">
                     <li><a href="<?php echo site_url('Logout')?>"><span class="fa fa-power-off "></span> Sing Out</a></li>
                  </ul>
                </li>
                <li ><a href="#" class="opener-right-menu"></span></a></li>
              </ul>
            </div>
          </div>
        </nav>