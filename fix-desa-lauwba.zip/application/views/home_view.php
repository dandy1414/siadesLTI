<?php $this->load->view('header');?>
<?php $this->load->view('sidebar');?>
<?php $this->load->view('footer');?>

