<script src="<?php echo base_url();?>asset/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>asset/js/jquery.ui.min.js"></script>
<script src="<?php echo base_url();?>asset/js/bootstrap.min.js"></script>
<!-- date time picker -->
<script type="text/javascript" src="<?php echo base_url('asset/date_picker_bootstrap/js/bootstrap-datetimepicker.js')?>" charset="UTF-8"></script>
<script type="text/javascript" src="<?php echo base_url('asset/date_picker_bootstrap/js/locales/bootstrap-datetimepicker.id.js')?>" charset="UTF-8"></script>


<!-- plugins -->
<script src="<?php echo base_url();?>asset/js/plugins/moment.min.js"></script>
<script src="<?php echo base_url();?>asset/js/plugins/jquery.datatables.min.js"></script>
<script src="<?php echo base_url();?>asset/js/plugins/datatables.bootstrap.min.js"></script>
<script src="<?php echo base_url();?>asset/js/plugins/bootstrap-material-datetimepicker.js"></script>
<script src="<?php echo base_url();?>asset/js/plugins/jquery.nicescroll.js"></script>


<!-- custom -->
<script src="<?php echo base_url();?>asset/js/main.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $('#datatables-example').DataTable();
  });
</script>
</body>
</html>